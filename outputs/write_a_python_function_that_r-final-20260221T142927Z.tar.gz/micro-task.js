// Micro-task: Creates a single loadtest_<n>.txt file
const fs = require('fs');
const path = require('path');

function createLoadTestFile(taskId, config) {
  return new Promise((resolve, reject) => {
    const fileName = `${config.filePrefix}${taskId}${config.fileExtension}`;
    const filePath = path.join(config.outputDir, fileName);
    
    fs.writeFile(filePath, config.fileContent + '\n', 'utf8', (err) => {
      if (err) {
        reject(new Error(`Failed to create ${fileName}: ${err.message}`));
      } else {
        resolve({ taskId, fileName, success: true });
      }
    });
  });
}

module.exports = { createLoadTestFile };
