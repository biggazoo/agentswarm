# Load Test Project

## Directory Structure
- `output/` - Contains generated loadtest_<n>.txt files
- `src/` - Contains task execution scripts

## Usage
Run the task runner to execute parallel load test tasks.
