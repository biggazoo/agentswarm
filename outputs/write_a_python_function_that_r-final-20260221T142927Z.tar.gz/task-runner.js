// Parallel Task Executor Script
// Usage: node task-runner.js [count]
// Default: 30 tasks if no count specified

const config = require('./config');
const { createLoadTestFile } = require('./micro-task');

function parseArgs() {
  const args = process.argv.slice(2);
  if (args.length > 0 && args[0] === '--count' && args[1]) {
    return parseInt(args[1], 10);
  }
  if (args.length > 0) {
    const parsed = parseInt(args[0], 10);
    if (!isNaN(parsed)) return parsed;
  }
  return config.taskCount;
}

async function runTasks(count) {
  console.log(`Starting parallel task execution with ${count} tasks...`);
  console.log(`File pattern: ${config.filePrefix}<n>${config.fileExtension}`);
  console.log('---');

  const startTime = Date.now();

  // Create array of task promises
  const taskPromises = [];
  for (let i = 1; i <= count; i++) {
    taskPromises.push(createLoadTestFile(i, config));
  }

  // Execute all tasks in parallel using Promise.all
  const results = await Promise.all(taskPromises);

  const endTime = Date.now();
  const duration = endTime - startTime;

  console.log('---');
  console.log(`Completed ${results.filter(r => r.success).length} tasks in ${duration}ms`);
  console.log(`Successfully created ${count} loadtest_*.txt files`);

  return results;
}

// Main execution
const taskCount = parseArgs();
runTasks(taskCount)
  .then(() => {
    console.log('\nAll tasks completed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Error during task execution:', error.message);
    process.exit(1);
  });
