// Configuration for parallel task execution
module.exports = {
  taskCount: 30,
  filePrefix: 'loadtest_',
  fileExtension: '.txt',
  fileContent: 'Load test task executed successfully',
  outputDir: '.'
};
