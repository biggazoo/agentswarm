import os

# Create the output directory if it doesn't exist
os.makedirs('output', exist_ok=True)
print("Output directory created successfully")
