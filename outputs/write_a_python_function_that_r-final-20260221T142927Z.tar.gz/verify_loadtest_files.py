#!/usr/bin/env python3
"""
Verify all 30 loadtest files exist and each contains exactly one line of text.
Creates any missing files if needed.
"""

import os
import glob

OUTPUT_DIR = "."
EXPECTED_COUNT = 30

def get_expected_filename(n):
    """Generate the expected filename for loadtest n."""
    return f"loadtest_{n}.txt"

def list_loadtest_files():
    """List all loadtest_*.txt files in the output directory."""
    pattern = os.path.join(OUTPUT_DIR, "loadtest_*.txt")
    files = glob.glob(pattern)
    return sorted(files)

def verify_files():
    """Verify all 30 loadtest files exist with exactly one line each."""
    print("=" * 60)
    print("LOADTEST FILES VERIFICATION")
    print("=" * 60)
    
    # Check each expected file
    existing_files = []
    missing_files = []
    files_with_wrong_line_count = []
    
    for n in range(1, EXPECTED_COUNT + 1):
        filename = get_expected_filename(n)
        filepath = os.path.join(OUTPUT_DIR, filename)
        
        if os.path.exists(filepath):
            existing_files.append(filename)
            # Check line count
            with open(filepath, 'r') as f:
                lines = f.readlines()
                line_count = len(lines)
                if line_count != 1:
                    files_with_wrong_line_count.append((filename, line_count))
        else:
            missing_files.append(filename)
    
    # Report results
    print(f"\nExpected files: {EXPECTED_COUNT}")
    print(f"Existing files: {len(existing_files)}")
    print(f"Missing files: {len(missing_files)}")
    
    # Create missing files if any
    if missing_files:
        print(f"\n--- Creating {len(missing_files)} missing files ---")
        for filename in missing_files:
            filepath = os.path.join(OUTPUT_DIR, filename)
            with open(filepath, 'w') as f:
                f.write(f"Load test data for {filename}\n")
            print(f"  Created: {filename}")
    
    # Report files with wrong line count
    if files_with_wrong_line_count:
        print(f"\n--- Files with wrong line count ---")
        for filename, count in files_with_wrong_line_count:
            print(f"  {filename}: {count} lines (expected 1)")
    
    # Final verification
    print("\n" + "=" * 60)
    print("FINAL VERIFICATION")
    print("=" * 60)
    
    all_valid = True
    
    for n in range(1, EXPECTED_COUNT + 1):
        filename = get_expected_filename(n)
        filepath = os.path.join(OUTPUT_DIR, filename)
        
        if not os.path.exists(filepath):
            print(f"FAIL: {filename} does not exist")
            all_valid = False
            continue
        
        with open(filepath, 'r') as f:
            lines = f.readlines()
            if len(lines) != 1:
                print(f"FAIL: {filename} has {len(lines)} lines (expected 1)")
                all_valid = False
            else:
                print(f"OK: {filename} (1 line)")
    
    print("\n" + "=" * 60)
    if all_valid:
        print(f"SUCCESS: All {EXPECTED_COUNT} files verified successfully!")
    else:
        print("FAILURE: Some files failed verification")
    print("=" * 60)
    
    return all_valid

if __name__ == "__main__":
    verify_files()
