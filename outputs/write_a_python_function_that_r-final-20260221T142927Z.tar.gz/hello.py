def hello_world():
    return 'hello world'


if __name__ == '__main__':
    print(hello_world())
